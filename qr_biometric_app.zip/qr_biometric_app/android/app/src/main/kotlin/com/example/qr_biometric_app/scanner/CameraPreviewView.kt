package com.example.qr_biometric_app.scanner

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.util.Size
import android.view.View
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.example.qr_biometric_app.MainActivity
import com.example.qr_biometric_app.sqlite.QrDatabaseHelper
import io.flutter.Log
import io.flutter.plugin.platform.PlatformView

class CameraPreviewView(private val context: Context) : PlatformView {
    private val previewView: PreviewView = PreviewView(context)
    var onQRCodeScanned: ((String) -> Unit)? = null

    companion object {
        // Permite que MainActivity acceda a la instancia de la vista para registrar el callback.
        @SuppressLint("StaticFieldLeak")
        var instance: CameraPreviewView? = null
    }

    init {
        instance = this
        startCamera()
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            // Use case para el preview
            val preview = Preview.Builder().build().apply {
                setSurfaceProvider(previewView.surfaceProvider)
            }
            // Use case para el análisis de imagen (QR)
            val imageAnalysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(1280, 720))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(context),
                QRCodeAnalyzer { qrCode ->
                    if (qrCode.isNotEmpty()) {
                        // Guardar el código QR en SQLite
                        val dbHelper = QrDatabaseHelper(context)
                        dbHelper.insertQrCode(qrCode)
                        // Llama al callback para notificar el resultado
                        onQRCodeScanned?.invoke(qrCode)
                        // Para detener el análisis después de detectar un QR, se desasigna el use case.
                        cameraProvider.unbind(imageAnalysis)
                    }
                }
            )
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            // Intentar obtener el Activity a partir del contexto
            val activity = (context as? Activity)
                ?: (if (context is android.content.MutableContextWrapper) context.baseContext as? Activity else null)
            // Usar el Activity almacenado en MainActivity como respaldo
            val validActivity = activity ?: MainActivity.currentActivity
            val lifecycleOwner = validActivity as? LifecycleOwner

            if (lifecycleOwner == null) {
                Log.e("CameraPreviewView", "No se pudo obtener un LifecycleOwner válido")
                return@addListener
            }
            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(lifecycleOwner, cameraSelector, preview, imageAnalysis)
            } catch (exc: Exception) {
                exc.printStackTrace()
            }
        }, ContextCompat.getMainExecutor(context))
    }

    // para detener la cámara
    private fun stopCamera() {
        // Obtenemos el cameraProvider y desvinculamos todos los casos de uso
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            cameraProvider.unbindAll()
            Log.i("CameraPreviewView", "Cámara detenida")
        }, ContextCompat.getMainExecutor(context))
    }

    override fun getView(): View = previewView

    override fun dispose() {
        // detener la cámara al desechar la vista
        stopCamera()
    }
}