import 'package:flutter/services.dart';

class NativeBridge {
  static const MethodChannel _channel = MethodChannel('com.example.qr_biometric_app/native');

  // Método para verificar la compatibilidad con autenticación biométrica
  static Future<bool> isBiometricAvailable() async {
    final bool available =
        await _channel.invokeMethod('isBiometricAvailable');
    return available;
  }

  static Future<String?> authenticateUser() async {
    return await _channel.invokeMethod('authenticateUser');
  }

  static Future<String?> scanQR() async {
    return await _channel.invokeMethod('scanQR');
  }
}