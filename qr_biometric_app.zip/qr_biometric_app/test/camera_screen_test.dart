import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:qr_biometric_app/presentation/screens/camera_screen.dart';

void main() {
  // Se define el canal de comunicación utilizado en NativeBridge
  const MethodChannel channel =
      MethodChannel('com.example.qr_biometric_app/native');

  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    // Se establece un handler simulado para el método 'scanQR'
    channel.setMockMethodCallHandler((MethodCall methodCall) async {
      if (methodCall.method == 'scanQR') {
        return 'https://example.com';
      }
      return null;
    });
  });

  tearDown(() {
    channel.setMockMethodCallHandler(null);
  });

  testWidgets('CameraScreen muestra el QR escaneado después de finalizar el análisis',
      (WidgetTester tester) async {
    // Se construye la pantalla de cámara
    await tester.pumpWidget(
      const MaterialApp(
        home: CameraScreen(),
      ),
    );

    // Inicialmente, se debe ver un CircularProgressIndicator (mientras se realiza el escaneo)
    //expect(find.byType(CircularProgressIndicator), findsOneWidget);

    // Se espera que el método nativo retorne el código QR simulado y se procese la UI
    await tester.pumpAndSettle();

    // Se verifica que se muestra el código QR en pantalla
    //expect(find.textContaining("Código QR:"), findsOneWidget);
    //expect(find.textContaining("https://example.com"), findsOneWidget);
  });
}