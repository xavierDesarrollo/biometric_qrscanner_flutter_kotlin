import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:qr_biometric_app/native/native_bridge.dart';
import 'package:qr_biometric_app/presentation/blocs/qr_bloc.dart';
import 'package:qr_biometric_app/presentation/screens/camera_screen.dart';

class BiometricAuthScreen extends StatefulWidget {
  const BiometricAuthScreen({super.key});

  @override
  _BiometricAuthScreenState createState() => _BiometricAuthScreenState();
}

class _BiometricAuthScreenState extends State<BiometricAuthScreen> {
  bool _biometricAvailable = false;

  @override
  void initState() {
    super.initState();
    _checkBiometricAvailability();
  }

  void _checkBiometricAvailability() async {
    final available = await NativeBridge.isBiometricAvailable();
    setState(() {
      _biometricAvailable = available;
    });
  }

  // Método para mostrar el fallback de autenticación con PIN
  void _showPinFallback(BuildContext context) {
    final TextEditingController pinController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Autenticación con PIN"),
          content: TextField(
            controller: pinController,
            keyboardType: TextInputType.number,
            obscureText: true,
            decoration: const InputDecoration(labelText: "Ingresa tu PIN"),
          ),
          actions: [
            TextButton(
              onPressed: () {
                final pin = pinController.text;
                Navigator.of(context).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("PIN ingresado: $pin")),
                );
              },
              child: const Text("Ingresar"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => QrBloc(),
      child: Scaffold(
        appBar: AppBar(title: const Text("Autenticación Biométrica")),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: BlocConsumer<QrBloc, QrState>(
              listener: (context, state) {
                if (state is AuthSuccess) {
                  // Navegar a CameraScreen al autenticarse correctamente
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(builder: (context) => const CameraScreen()),
                  );
                } else if (state is AuthFailure) {
                  _showPinFallback(context);
                }
              },
              builder: (context, state) {
                if (state is QrScanInProgress) {
                  return const CircularProgressIndicator();
                }
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      _biometricAvailable
                          ? "El dispositivo soporta autenticación biométrica."
                          : "Autenticación biométrica no disponible en este dispositivo.",
                      style: const TextStyle(fontSize: 18),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: _biometricAvailable
                          ? () {
                              // Inicia la autenticación biométrica
                              BlocProvider.of<QrBloc>(context)
                                  .add(AuthenticateUser());
                            }
                          : null, // Deshabilita el botón si no está disponible
                      child: const Text("Iniciar autenticación biométrica"),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}