package com.example.qr_biometric_app

import android.annotation.SuppressLint
import android.app.Activity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import androidx.annotation.NonNull
import com.example.qr_biometric_app.biometric.BiometricAuth
import com.example.qr_biometric_app.scanner.CameraPreviewFactory
import com.example.qr_biometric_app.scanner.CameraPreviewView
import io.flutter.embedding.android.FlutterFragmentActivity

class MainActivity: FlutterFragmentActivity() {
    private val CHANNEL = "com.example.qr_biometric_app/native"

    companion object {
        // Se utiliza para enviar el resultado una vez que se detecta el código QR
        var qrScanResult: MethodChannel.Result? = null
        @SuppressLint("StaticFieldLeak")
        var currentActivity: Activity? = null
    }

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // Registrar la vista nativa para el preview de cámara
        flutterEngine.platformViewsController.registry.registerViewFactory("camera_preview", CameraPreviewFactory(flutterEngine.dartExecutor.binaryMessenger))

        // Si sigues utilizando MethodChannel, configúralo aquí también
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when(call.method) {
                "isBiometricAvailable" -> {
                    val biometricAuth = BiometricAuth(this)
                    val available = biometricAuth.isBiometricAvailable()
                    result.success(available)
                }
                "scanQR" -> {
                    // Se guarda el callback para enviarlo cuando se detecte un QR.
                    qrScanResult = result
                    // Configuramos el callback en la instancia de CameraPreviewView
                    CameraPreviewView.instance?.onQRCodeScanned = { qrCode ->
                        qrScanResult?.success(qrCode)
                        qrScanResult = null
                    }
                }
                "authenticateUser" -> {
                    BiometricAuth(this).authenticate(
                        onSuccess = { result.success("Autenticación exitosa") },
                        onFailure = { error -> result.success("Error: $error") }
                    )
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        currentActivity = this
    }

    override fun onPause() {
        super.onPause()
        if (currentActivity === this) {
            currentActivity = null
        }
    }
}