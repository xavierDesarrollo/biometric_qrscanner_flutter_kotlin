package com.example.qr_biometric_app.scanner

import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.zxing.*
import com.google.zxing.common.HybridBinarizer
import java.nio.ByteBuffer

class QRCodeAnalyzer(private val onQRCodeScanned: (String) -> Unit) : ImageAnalysis.Analyzer {

    private fun ByteBuffer.toByteArray(): ByteArray {
        rewind()
        val data = ByteArray(remaining())
        get(data)
        return data
    }

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(image: ImageProxy) {
        val mediaImage = image.image
        if (mediaImage != null) {
            // Usamos solo el plano Y para el análisis (imagen en escala de grises)
            val buffer = image.planes[0].buffer
            val bytes = buffer.toByteArray()
            val width = image.width
            val height = image.height
            try {
                val source = PlanarYUVLuminanceSource(
                    bytes, width, height, 0, 0, width, height, false
                )
                val bitmap = BinaryBitmap(HybridBinarizer(source))
                val reader = MultiFormatReader().apply {
                    setHints(mapOf(DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE)))
                }
                val result = reader.decode(bitmap)
                onQRCodeScanned(result.text)
            } catch (e: Exception) {
                // No se detectó ningún QR en este frame, se ignora la excepción.
            } finally {
                image.close()
            }
        } else {
            image.close()
        }
    }
}