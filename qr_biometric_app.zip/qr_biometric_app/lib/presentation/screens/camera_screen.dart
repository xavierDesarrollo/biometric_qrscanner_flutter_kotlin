import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:qr_biometric_app/native/native_bridge.dart';
import 'package:qr_biometric_app/presentation/screens/biometric_auth_screen.dart';


class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});

  @override
  _CameraScreenState createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  String? _scannedCode;
  bool _scanning = false;

  @override
  void initState() {
    super.initState();
     _requestCameraPermission().then((granted) {
      if (granted) {
        _startScanning();
      } else {
        debugPrint("Permiso de cámara denegado.");
      }
    });
  }

  void _startScanning() async {
    setState(() {
      _scanning = true;
    });
    // Llamada al método nativo que inicia el escaneo y guarda el código en SQLite
    final result = await NativeBridge.scanQR();
    setState(() {
      _scannedCode = result;
      _scanning = false;
    });
    // Si se ha recibido un código QR, muestra un Toast
    if (_scannedCode != null && _scannedCode!.isNotEmpty) {
      _showToast(_scannedCode!);
    }
  }

  // Solicita el permiso de cámara
  Future<bool> _requestCameraPermission() async {
    var status = await Permission.camera.status;
    if (!status.isGranted) {
      status = await Permission.camera.request();
    }
    return status.isGranted;
  }

  void _showToast(String qrCode) {
    Fluttertoast.showToast(
      msg: "Código QR guardado en base de datos local",
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: Colors.black54,
      textColor: Colors.white,
      fontSize: 16.0,
    );
  }

  void _logout() {
    // Navega de regreso a la pantalla de autenticación biométrica
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => const BiometricAuthScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Camera Screen")),
      body: Column(
        children: [
          // Área central con preview de cámara y resultado del escaneo
          Expanded(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Vista nativa de cámara en un contenedor de 200x200 px
                  const SizedBox(
                    width: 600,
                    height: 300,
                    child: AndroidView(
                      viewType: "camera_preview",
                    ),
                  ),
                  const SizedBox(height: 20),
                  if (_scanning)
                    const CircularProgressIndicator()
                  else if (_scannedCode != null)
                    Text(
                      "Código QR: $_scannedCode",
                      style: const TextStyle(fontSize: 18),
                      textAlign: TextAlign.center,
                    ),
                ],
              ),
            ),
          ),
          // Botón en el bottom para cerrar sesión y volver a la pantalla de autenticación
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              onPressed: _logout,
              child: const Text("Cerrar sesión"),
            ),
          ),
        ],
      ),
    );
  }
}