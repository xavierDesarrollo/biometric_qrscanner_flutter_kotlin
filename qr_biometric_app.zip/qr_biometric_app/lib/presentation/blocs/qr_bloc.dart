import 'package:bloc/bloc.dart';
import 'package:qr_biometric_app/native/native_bridge.dart';

// Define los eventos
abstract class QrEvent {}
class StartQrScan extends QrEvent {}
class AuthenticateUser extends QrEvent {}

// Define los estados
abstract class QrState {}
class InitialState extends QrState {}
class QrScanInProgress extends QrState {}
class QrScanSuccess extends QrState {
  final String result;
  QrScanSuccess(this.result);
}
class AuthSuccess extends QrState {
  
}
class AuthFailure extends QrState {
  final String error;
  AuthFailure(this.error);
}

class QrBloc extends Bloc<QrEvent, QrState> {
  QrBloc() : super(InitialState()) {
    on<StartQrScan>((event, emit) async {
      emit(QrScanInProgress());
      final result = await NativeBridge.scanQR();
      emit(QrScanSuccess(result ?? "Sin resultado"));
    });
    on<AuthenticateUser>((event, emit) async {
      final result = await NativeBridge.authenticateUser();
      if(result?.contains("Autenticación exitosa") ?? false) {
        emit(AuthSuccess());
      } else {
        emit(AuthFailure(result ?? "Error desconocido"));
      }
    });
  }
}